var1=int(input("introduce un número:"))
var2=int(input("introduce otro número:"))
total1=var1+var2
total2=var1-var2
total3=var1*var2
total4=var1/var2
total4= round(total4, 2)
total5=var1**var2
total6=var1//var2
total7=var1%var2
print(f"la suma es:",total1)
print(f"la resta es:", total2)
print(f"la multiplicación es:", total3)
print(f"la división es:",total4)
print(f"la potencia es:", total5)
print(f"la división con resultado de número entero es:", total6)
print(f"el modulo entre operadores es:", total7)
