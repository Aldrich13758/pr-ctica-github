var1=int(input("introduce un número de segundos:"))
total1=var1/60
total2=var1/3600
print(f"el número total de minutos es:{total1} el número de horas es", total2)