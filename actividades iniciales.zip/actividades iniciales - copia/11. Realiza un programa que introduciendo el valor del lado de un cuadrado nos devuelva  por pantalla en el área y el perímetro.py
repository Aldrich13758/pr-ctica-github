var1=int(input("introduce la medida del lado de un cuadrado:"))
total1=var1*4
total2=var1*var1
print(f"el área del cuadrado es: {total2}cm cuadrados y el perímetro es: {total1}cm")