var1=float(input("introduce un número decimal:"))
var2=float(input("introduce otro número decimal"))
total=var1+var2
print(f"el resultado de la suma de ambos números es:", total)