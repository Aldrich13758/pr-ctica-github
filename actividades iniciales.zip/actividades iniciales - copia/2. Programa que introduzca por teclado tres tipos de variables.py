var1=int(input("introduce un número entero:"))
var2=(input("introduce una letra:"))
var3=float(input("introduce un número decimal:"))
print(f"los valores introducidos son: {var1}, {var2}, {var3}")