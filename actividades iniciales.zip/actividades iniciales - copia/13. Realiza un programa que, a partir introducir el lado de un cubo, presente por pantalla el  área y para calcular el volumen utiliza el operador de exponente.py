var1=int(input("introduce la medida del lado de un cubo:"))
total1=6*var1**2
total2=var1**3
print(f"el área del cubo es: {total1} y el volumen del cubo es: {total2}")