var1=float(input("introduce un número de horas:"))
total=var1*60
total2=var1*3600
print(f"el número de minutos es {total} y el número de segundos es {total2}")