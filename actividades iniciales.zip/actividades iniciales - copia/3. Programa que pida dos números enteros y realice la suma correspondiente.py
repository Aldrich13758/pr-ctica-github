var1=int(input("introduce un número:"))
var2=int(input("introduce otro número"))
total=var1+var2
print(f"el resultado de la suma de ambos números sería:", total)